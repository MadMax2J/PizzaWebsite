<?php
/**
 * db_config.php
 * Created by PhpStorm.
 * User: jbyrne
 * Date: 14/04/2015
 * Time: 19:50
 */


define('DB_USER', "root"); // db user
define('DB_PASSWORD', ""); // db password (mention your db password here)
define('DB_DATABASE', "pizza"); // database name
define('DB_SERVER', "localhost"); // db server

?>